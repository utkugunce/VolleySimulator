import { redirect } from "next/navigation";

export default function CEVChallengePage() {
    redirect("/cev-challenge/gunceldurum");
}
