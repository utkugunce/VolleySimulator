"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "../context/AuthContext";
import { validators, sanitize } from "../utils/validation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowRight, ArrowLeft, AlertCircle, Gamepad2 } from "lucide-react";

export default function RegisterPage() {
    const router = useRouter();
    const { signUp, signInWithGoogle, user } = useAuth();

    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
        favoriteTeam: ""
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");
    const [step, setStep] = useState(1);

    // Redirect if already logged in
    if (user) {
        router.push('/profile');
        return null;
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (step === 1) {
            // Use validation utilities
            const nameError = validators.string.required(formData.name, "Ad gerekli");
            const emailError = validators.string.required(formData.email, "E-posta gerekli")
                || validators.string.email(formData.email, "Geçerli bir e-posta girin");

            if (nameError || emailError) {
                setError(nameError || emailError || "");
                return;
            }
            // Sanitize inputs
            setFormData(prev => ({
                ...prev,
                name: sanitize.normalizeWhitespace(prev.name),
                email: prev.email.trim().toLowerCase()
            }));
            setError("");
            setStep(2);
            return;
        }

        if (formData.password !== formData.confirmPassword) {
            setError("Şifreler eşleşmiyor");
            return;
        }

        if (formData.password.length < 6) {
            setError("Şifre en az 6 karakter olmalı");
            return;
        }

        setIsLoading(true);
        setError("");

        const { error } = await signUp(formData.email, formData.password, {
            name: formData.name
        });

        if (error) {
            setError(error.message === "User already registered"
                ? "Bu e-posta zaten kayıtlı"
                : error.message
            );
            setIsLoading(false);
        } else {
            // Save favorite team to localStorage for now
            if (formData.favoriteTeam) {
                localStorage.setItem('favoriteTeam', formData.favoriteTeam);
            }
            router.push('/profile');
        }
    };

    return (
        <main className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
            <div className="w-full max-w-md">
                {/* Header */}
                <div className="text-center mb-8">
                    <Link href="/" className="inline-block mb-4">
                        <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-teal-200">
                            VolleySimulator
                        </span>
                    </Link>
                    <h1 className="text-3xl font-black">Kayıt Ol</h1>
                    <p className="text-muted-foreground text-sm mt-2">Tahmin oyununa katıl ve XP kazan!</p>
                </div>

                {/* Progress Steps */}
                <div className="flex items-center justify-center gap-4 mb-6">
                    <div className={`flex items-center gap-2 ${step >= 1 ? 'text-primary' : 'text-muted-foreground'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                            1
                        </div>
                        <span className="text-sm font-medium hidden sm:inline">Bilgiler</span>
                    </div>
                    <div className={`w-12 h-0.5 ${step >= 2 ? 'bg-primary' : 'bg-muted'}`} />
                    <div className={`flex items-center gap-2 ${step >= 2 ? 'text-primary' : 'text-muted-foreground'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                            2
                        </div>
                        <span className="text-sm font-medium hidden sm:inline">Şifre</span>
                    </div>
                </div>

                {/* Register Form */}
                <Card>
                    <CardContent className="pt-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            {error && (
                                <Alert variant="destructive">
                                    <AlertCircle className="h-4 w-4" />
                                    <AlertDescription>{error}</AlertDescription>
                                </Alert>
                            )}

                            {step === 1 ? (
                                <>
                                    <div className="space-y-2">
                                        <Label htmlFor="name">Kullanıcı Adı</Label>
                                        <Input
                                            id="name"
                                            type="text"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleChange}
                                            placeholder="Takma adın"
                                            required
                                        />
                                    </div>

                                    <div className="space-y-2">
                                        <Label htmlFor="email">E-posta</Label>
                                        <Input
                                            id="email"
                                            type="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            placeholder="ornek@email.com"
                                            required
                                        />
                                    </div>

                                    <div className="space-y-2">
                                        <Label>Favori Takım (Opsiyonel)</Label>
                                        <Select
                                            value={formData.favoriteTeam}
                                            onValueChange={(value) => setFormData({ ...formData, favoriteTeam: value })}
                                        >
                                            <SelectTrigger>
                                                <SelectValue placeholder="Takım seç..." />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Fenerbahçe Medicana">Fenerbahçe Medicana</SelectItem>
                                                <SelectItem value="VakıfBank">VakıfBank</SelectItem>
                                                <SelectItem value="Eczacıbaşı Dynavit">Eczacıbaşı Dynavit</SelectItem>
                                                <SelectItem value="THY">THY</SelectItem>
                                                <SelectItem value="Galatasaray">Galatasaray</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        <p className="text-xs text-amber-500">+20% XP bonus favori takımın maçlarında!</p>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="space-y-2">
                                        <Label htmlFor="password">Şifre</Label>
                                        <Input
                                            id="password"
                                            type="password"
                                            name="password"
                                            value={formData.password}
                                            onChange={handleChange}
                                            placeholder="En az 6 karakter"
                                            required
                                            minLength={6}
                                        />
                                    </div>

                                    <div className="space-y-2">
                                        <Label htmlFor="confirmPassword">Şifre Tekrar</Label>
                                        <Input
                                            id="confirmPassword"
                                            type="password"
                                            name="confirmPassword"
                                            value={formData.confirmPassword}
                                            onChange={handleChange}
                                            placeholder="Şifreyi tekrar gir"
                                            required
                                        />
                                    </div>

                                    <div className="bg-muted rounded-lg p-4">
                                        <div className="text-xs text-muted-foreground mb-2">Kayıt olduğunda kazanacakların:</div>
                                        <div className="flex flex-wrap gap-2">
                                            <Badge variant="secondary" className="bg-amber-500/20 text-amber-400">+50 XP</Badge>
                                            <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-400">🎯 İlk Adım Rozeti</Badge>
                                        </div>
                                    </div>
                                </>
                            )}

                            <div className="flex gap-3">
                                {step === 2 && (
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => setStep(1)}
                                        className="flex-1"
                                    >
                                        <ArrowLeft className="mr-2 h-4 w-4" />
                                        Geri
                                    </Button>
                                )}
                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500"
                                >
                                    {isLoading ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Kayıt yapılıyor...
                                        </>
                                    ) : step === 1 ? (
                                        <>
                                            Devam Et
                                            <ArrowRight className="ml-2 h-4 w-4" />
                                        </>
                                    ) : (
                                        <>
                                            <Gamepad2 className="mr-2 h-4 w-4" />
                                            Kayıt Ol
                                        </>
                                    )}
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>

                {/* Divider */}
                <div className="relative my-6">
                    <Separator />
                    <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-4 text-muted-foreground text-sm">
                        veya
                    </span>
                </div>

                {/* Google Sign Up */}
                <Button
                    type="button"
                    variant="outline"
                    onClick={signInWithGoogle}
                    className="w-full"
                >
                    <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                    </svg>
                    Google ile Kayıt Ol
                </Button>

                {/* Login Link */}
                <p className="text-center mt-6 text-muted-foreground">
                    Zaten hesabın var mı?{" "}
                    <Link href="/login" className="text-primary font-bold hover:underline">
                        Giriş Yap
                    </Link>
                </p>
            </div>
        </main>
    );
}
