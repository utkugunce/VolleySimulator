"use client";

// Prevent static prerendering - this page requires auth context
export const dynamic = 'force-dynamic';

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "../context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Loader2, ArrowRight, AlertCircle } from "lucide-react";

import LoginBackground from "../components/LoginBackground";

export default function LoginPage() {
    const router = useRouter();
    const { signIn, signInWithGoogle, user } = useAuth();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");

    // Redirect if already logged in
    useEffect(() => {
        if (user) {
            router.push('/ligler');
        }
    }, [user, router]);

    if (user) {
        return null;
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError("");

        const { error } = await signIn(email, password);

        if (error) {
            setError(error.message === "Invalid login credentials"
                ? "E-posta veya şifre hatalı"
                : error.message
            );
            setIsLoading(false);
        } else {
            router.push('/ligler');
        }
    };

    const handleGoogleLogin = async () => {
        await signInWithGoogle();
    };

    return (
        <main className="min-h-screen relative flex flex-col items-center justify-center p-4 overflow-hidden">
            <LoginBackground />

            <div className="w-full max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 items-center relative z-10">

                {/* Left Side: Brand & Features (Desktop) */}
                <div className="hidden lg:block space-y-8 animate-fade-in-left">
                    <div className="space-y-2">
                        <Link href="/" className="inline-block">
                            <span className="text-4xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-400">
                                VolleySimulator
                            </span>
                        </Link>
                        <h1 className="text-2xl font-light text-slate-300">
                            Voleybol Tutkunları İçin <br />
                            <span className="font-semibold text-white">Yeni Nesil Simülasyon</span>
                        </h1>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-slate-900/40 backdrop-blur-sm border border-slate-700/50 p-4 rounded-2xl">
                            <div className="text-3xl mb-2">🏆</div>
                            <h3 className="font-bold text-white mb-1">Tahmin Oyunu</h3>
                            <p className="text-sm text-slate-400">Maç skorlarını tahmin et, puanları topla ve liderliğe yüksel.</p>
                        </div>
                        <div className="bg-slate-900/40 backdrop-blur-sm border border-slate-700/50 p-4 rounded-2xl">
                            <div className="text-3xl mb-2">📊</div>
                            <h3 className="font-bold text-white mb-1">Detaylı Analiz</h3>
                            <p className="text-sm text-slate-400">Takım form durumları ve yapay zeka destekli maç analizleri.</p>
                        </div>
                        <div className="bg-slate-900/40 backdrop-blur-sm border border-slate-700/50 p-4 rounded-2xl">
                            <div className="text-3xl mb-2">⚡</div>
                            <h3 className="font-bold text-white mb-1">Canlı Skor</h3>
                            <p className="text-sm text-slate-400">Maç sonuçlarını anlık takip et, ligdeki gelişmeleri kaçırma.</p>
                        </div>
                        <div className="bg-slate-900/40 backdrop-blur-sm border border-slate-700/50 p-4 rounded-2xl">
                            <div className="text-3xl mb-2">🌍</div>
                            <h3 className="font-bold text-white mb-1">Topluluk</h3>
                            <p className="text-sm text-slate-400">Diğer voleybol severlerle yarış ve sıralamada yerini al.</p>
                        </div>
                    </div>
                </div>

                {/* Right Side: Login Card */}
                <div className="w-full max-w-md mx-auto lg:ml-auto">
                    <Card className="bg-background/60 backdrop-blur-xl border-border/50 shadow-2xl">
                        <CardHeader className="text-center">
                            {/* Mobile Header (Visible only on mobile) */}
                            <div className="lg:hidden mb-4">
                                <Link href="/" className="inline-block mb-2">
                                    <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-teal-200">
                                        VolleySimulator
                                    </span>
                                </Link>
                            </div>
                            <CardTitle className="text-2xl">Giriş Yap</CardTitle>
                            <CardDescription>Hesabınıza erişmek için bilgilerinizi girin</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {/* Login Form */}
                            <form onSubmit={handleSubmit} className="space-y-4">
                                {error && (
                                    <Alert variant="destructive">
                                        <AlertCircle className="h-4 w-4" />
                                        <AlertDescription>{error}</AlertDescription>
                                    </Alert>
                                )}

                                <div className="space-y-2">
                                    <Label htmlFor="email">E-posta</Label>
                                    <Input
                                        id="email"
                                        type="email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        placeholder="ornek@email.com"
                                        required
                                    />
                                </div>

                                <div className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <Label htmlFor="password">Şifre</Label>
                                        <Link href="#" className="text-xs text-primary hover:underline">
                                            Unuttum?
                                        </Link>
                                    </div>
                                    <Input
                                        id="password"
                                        type="password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="••••••••"
                                        required
                                    />
                                </div>

                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500"
                                >
                                    {isLoading ? (
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                        <>
                                            Giriş Yap
                                            <ArrowRight className="ml-2 h-4 w-4" />
                                        </>
                                    )}
                                </Button>
                            </form>

                            <div className="relative my-6">
                                <Separator />
                                <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-2 text-xs text-muted-foreground">
                                    veya
                                </span>
                            </div>

                            <Button
                                type="button"
                                variant="outline"
                                onClick={handleGoogleLogin}
                                className="w-full"
                            >
                                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                                </svg>
                                Google ile devam et
                            </Button>

                            <p className="mt-6 text-center text-sm text-muted-foreground">
                                Hesabın yok mu?{" "}
                                <Link href="/register" className="text-primary font-medium hover:underline">
                                    Hemen Kayıt Ol
                                </Link>
                            </p>
                        </CardContent>
                    </Card>

                    {/* Skip Link (Subtle) */}
                    <div className="text-center mt-6">
                        <Link href="/1lig/tahminoyunu" className="text-muted-foreground text-xs hover:text-foreground transition-colors flex items-center justify-center gap-1 group">
                            Giriş yapmadan siteye göz at
                            <span className="group-hover:translate-x-1 transition-transform">→</span>
                        </Link>
                    </div>
                </div>
            </div>

            <style jsx>{`
                @keyframes fade-in-up {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                @keyframes fade-in-left {
                    from { opacity: 0; transform: translateX(-20px); }
                    to { opacity: 1; transform: translateX(0); }
                }
                .animate-fade-in-up {
                    animation: fade-in-up 0.6s ease-out forwards;
                }
                .animate-fade-in-left {
                    animation: fade-in-left 0.6s ease-out forwards;
                    animation-delay: 0.2s;
                    opacity: 0;
                }
            `}</style>
        </main>
    );
}
