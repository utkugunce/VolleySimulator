import { redirect } from "next/navigation";

export default function CEVCupPage() {
    redirect("/cev-cup/gunceldurum");
}
